/* ==========================================================================
   Body Scent - Shared JavaScript (product.html, order.html, admin.html)
   ========================================================================== */

const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbybm_5hEsU7NqDQ4P1Al4paLxaJLz6ZP1VjaKJsA2Uc2wpoumr12MprKICkvW4FV5t3/exec';
const GOOGLE_SHEET_CSV_URL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vSH6DABaaMD_4F24PNX98CLMNf74o8wc_FVWOrwn21Jy0Cp1R8E8p5xT0lEODtAcJmo8pNvLTvws1Ne/pub?gid=0&single=true&output=csv';

document.addEventListener('DOMContentLoaded', () => {
  // 1. ตรวจสอบหน้า product.html
  if (document.getElementById('product-list')) {
    initProductPage();
  }

  // 2. ตรวจสอบหน้า order.html
  if (document.getElementById('orderForm')) {
    initOrderPage();
  }

  // 3. ตรวจสอบหน้า admin.html
  if (document.querySelector('#ordersTable tbody')) {
    initAdminPage();
  }
});

/* ==========================================================================
   1. หน้าสินค้า (product.html)
   ========================================================================== */
function initProductPage() {
  const filterBar = document.getElementById('filter-bar');
  const productList = document.getElementById('product-list');
  let allProducts = [];

  const moods = [
    { key: 'all', label: 'ทั้งหมด' },
    { key: 'fresh', label: 'Fresh' },
    { key: 'sweet', label: 'Sweet' },
    { key: 'confident', label: 'Confident' },
    { key: 'romance', label: 'Romance' }
  ];

  // อ่านค่า ?mood=xxx จาก URL
  const urlParams = new URLSearchParams(window.location.search);
  const initialMoodParam = (urlParams.get('mood') || 'all').toLowerCase();
  const validMoodKeys = moods.map(m => m.key);
  let activeMood = validMoodKeys.includes(initialMoodParam) ? initialMoodParam : 'all';

  // สร้างปุ่มกรองตาม mood
  if (filterBar) {
    filterBar.innerHTML = moods.map(m => {
      const dotHtml = m.key !== 'all' ? `<span class="mood-dot ${m.key}"></span>` : '';
      const activeClass = m.key === activeMood ? 'active' : '';
      return `<button type="button" class="filter-btn ${activeClass}" data-mood="${m.key}">${dotHtml}${m.label}</button>`;
    }).join('');

    filterBar.addEventListener('click', (e) => {
      const btn = e.target.closest('.filter-btn');
      if (!btn) return;

      activeMood = btn.dataset.mood;

      // อัปเดตสถานะปุ่ม active
      filterBar.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      renderProducts(activeMood);
    });
  }

  // โหลดข้อมูลจาก products.json
  fetch('products.json')
    .then(response => {
      if (!response.ok) throw new Error('ไม่สามารถโหลดข้อมูลสินค้าได้');
      return response.json();
    })
    .then(data => {
      allProducts = data;
      renderProducts(activeMood);
    })
    .catch(error => {
      console.error(error);
      productList.innerHTML = '<p style="text-align:center; grid-column: 1/-1; color: var(--text-secondary);">ไม่สามารถโหลดรายการสินค้าได้ในขณะนี้</p>';
    });

  function renderProducts(moodFilter) {
    const filtered = moodFilter === 'all'
      ? allProducts
      : allProducts.filter(p => p.mood.toLowerCase() === moodFilter);

    if (filtered.length === 0) {
      productList.innerHTML = '<p style="text-align:center; grid-column: 1/-1; color: var(--text-secondary);">ไม่พบสินค้าในหมวดหมู่นี้</p>';
      return;
    }

    productList.innerHTML = filtered.map(product => {
      const orderUrl = `order.html?item=${encodeURIComponent(product.name)}&price=${encodeURIComponent(product.price)}`;
      const typeLabel = product.type === 'rollon' ? 'Roll-On' : 'Body Mist';

      return `
        <article class="product-card">
          <div class="product-image-wrap">
            <span class="product-type-tag">${typeLabel}</span>
            <img src="${product.image}" alt="${product.name}" loading="lazy">
          </div>
          <div class="product-body">
            <div class="product-mood-label">
              <span class="mood-dot ${product.mood}"></span>
              <span>${product.mood} &bull; ${product.size}</span>
            </div>
            <h3 class="product-title">${product.name}</h3>
            <div class="mood-line ${product.mood}"></div>
            <p class="product-desc">${product.description || ''}</p>
            <div class="product-footer">
              <span class="product-price">฿${product.price}</span>
              <a href="${orderUrl}" class="btn btn-sm">สั่งซื้อ</a>
            </div>
          </div>
        </article>
      `;
    }).join('');
  }
}

/* ==========================================================================
   2. หน้าสั่งซื้อ (order.html)
   ========================================================================== */
function initOrderPage() {
  const orderForm = document.getElementById('orderForm');
  const customerNameInput = document.getElementById('customerName');
  const contactInput = document.getElementById('contact');
  const itemsInput = document.getElementById('items');
  const totalInput = document.getElementById('total');
  const noteInput = document.getElementById('note');

  // อ่านค่า item และ price จาก URL parameter แล้วเติมลงฟอร์มอัตโนมัติ
  const urlParams = new URLSearchParams(window.location.search);
  const itemParam = urlParams.get('item');
  const priceParam = urlParams.get('price');

  if (itemParam && itemsInput) {
    itemsInput.value = itemParam;
  }

  if (priceParam && totalInput) {
    totalInput.value = priceParam;
  }

  // จัดการการส่งฟอร์มสั่งซื้อ
  orderForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const submitBtn = orderForm.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn ? submitBtn.textContent : '';
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = 'กำลังบันทึกคำสั่งซื้อ...';
    }

    const payload = {
      customerName: customerNameInput ? customerNameInput.value.trim() : '',
      contact: contactInput ? contactInput.value.trim() : '',
      items: itemsInput ? itemsInput.value.trim() : '',
      total: totalInput ? totalInput.value.trim() : '',
      note: noteInput ? noteInput.value.trim() : ''
    };

    fetch(APPS_SCRIPT_URL, {
      method: 'POST',
      body: JSON.stringify(payload)
    })
      .then(() => {
        window.location.href = 'thankyou.html';
      })
      .catch(error => {
        console.error(error);
        alert('เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง');
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = originalBtnText;
        }
      });
  });
}

/* ==========================================================================
   3. หน้าแอดมิน (admin.html)
   ========================================================================== */
function initAdminPage() {
  const tbody = document.querySelector('#ordersTable tbody');

  tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 2rem; color: var(--text-secondary);">กำลังโหลดข้อมูลคำสั่งซื้อ...</td></tr>';

  fetch(GOOGLE_SHEET_CSV_URL)
    .then(response => {
      if (!response.ok) throw new Error('ไม่สามารถดึงข้อมูลจาก Google Sheets ได้');
      return response.text();
    })
    .then(csvText => {
      const rows = parseCSV(csvText);

      // ตัดแถวหัวตาราง (Header) ออก และกรองแถวว่างทิ้ง
      const dataRows = rows.slice(1).filter(row => row.some(cell => cell.trim() !== ''));

      if (dataRows.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 2rem; color: var(--text-secondary);">ยังไม่มีรายการสั่งซื้อ</td></tr>';
        return;
      }

      // เรียงจากรายการล่าสุดขึ้นก่อน
      const reversedRows = dataRows.reverse();

      tbody.innerHTML = reversedRows.map(row => {
        // คอลัมน์: 0=วันเวลา, 1=ชื่อลูกค้า, 2=เบอร์โทร/Line, 3=รายการสินค้า, 4=จำนวนเงินรวม, 5=หมายเหตุ
        const timestamp = escapeHTML(row[0] || '-');
        const customerName = escapeHTML(row[1] || '-');
        const contact = escapeHTML(row[2] || '-');
        const items = escapeHTML(row[3] || '-');
        const total = escapeHTML(row[4] || '-');
        const note = escapeHTML(row[5] || '-');

        return `
          <tr>
            <td>${timestamp}</td>
            <td>${customerName}</td>
            <td>${contact}</td>
            <td>${items}</td>
            <td>${total}</td>
            <td>${note}</td>
          </tr>
        `;
      }).join('');
    })
    .catch(error => {
      console.error(error);
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 2rem; color: var(--mood-romance);">เกิดข้อผิดพลาดในการโหลดข้อมูล</td></tr>';
    });
}

/* ==========================================================================
   Helper Functions: CSV Parser & HTML Escaper
   ========================================================================== */
function parseCSV(text) {
  const rows = [];
  let currentRow = [];
  let currentVal = '';
  let insideQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];

    if (char === '"') {
      if (insideQuotes && nextChar === '"') {
        // เครื่องหมายคำพูดซ้อน ("") ภายในฟิลด์
        currentVal += '"';
        i++;
      } else {
        insideQuotes = !insideQuotes;
      }
    } else if (char === ',' && !insideQuotes) {
      currentRow.push(currentVal.trim());
      currentVal = '';
    } else if ((char === '' || char === '
') && !insideQuotes) {
      if (char === '' && nextChar === '
') {
        i++;
      }
      currentRow.push(currentVal.trim());
      rows.push(currentRow);
      currentRow = [];
      currentVal = '';
    } else {
      currentVal += char;
    }
  }

  // เก็บข้อมูลตัวสุดท้ายถ้าไม่มีขึ้นบรรทัดใหม่ปิดท้าย
  if (currentVal.length > 0 || currentRow.length > 0) {
    currentRow.push(currentVal.trim());
    rows.push(currentRow);
  }

  return rows;
}

function escapeHTML(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
